# ---------------------------------------------- #
# Title: Assignment07TryExcept.py
# Dev: Andrew Garcia
# Date: 12/2/2018
# Changelog: Andrew Garcia, 12/2/2018, Created
# ---------------------------------------------- #
# Simple script to show try-except
# Takes two user inputs and divides the two numbers


try:
    # get two user inputs
    firstNumber = float(input("Enter a number: "))
    secondNumber = float(input("Enter another number: "))
# tries to divide both numbers
    division = firstNumber/secondNumber
    print(division)
# prints error if both numbers aren't integers or floats
except ValueError:
    print("Make sure both your numbers are integers or floats!")
    input("Press enter to continue.")
# prints error if user divides by zero
except ZeroDivisionError:
    print("You cannot divide a number by zero!")
    input("Press enter to continue.")
# prints to show that division was successful
else:
    print("Division successful!")
    input("Press enter to continue.")
