# ---------------------------------------------- #
# Title: Assignment07Pickle.py
# Dev: Andrew Garcia
# Date: 12/2/2018
# Changelog: Andrew Garcia, 12/2/2018, Created
# ---------------------------------------------- #
# Simple script to show pickle
# Takes a username and password from user, using pickling to save data to file.

# import the pickle module, which does the pickling
import pickle

#get user input
userName = input("Enter your username: ")
userPass = input("Enter your password: ")
userInfo = [userName, userPass]
print(userInfo)

# pickle and save user and password to text file
dataFile = open("UserAndPass.txt", "wb")
pickle.dump(userInfo, dataFile)
dataFile.close()

# open text file, unpickle, and read data
dataFile = open("UserAndPass.txt", "rb")
newUserInfo = pickle.load(dataFile)
dataFile.close()
# print current info in text file
print("Your current info is", newUserInfo)
input("Press the enter key to continue.")
