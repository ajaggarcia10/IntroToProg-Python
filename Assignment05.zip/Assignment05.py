# ---------------------------------------------- #
# Title: HomeInventory
# Dev: Andrew Garcia
# Date: 11/10/2018
# Changelog: Andrew Garcia, 11/10/2018, Created
# ---------------------------------------------- #

#script that allows users to look at their to do list and be able to edit the list as they choose
print("Welcome to your To Do List!")
print("Here you can perform different tasks related to your to do list.")

# create text file with some data
textFile = open("ToDo.txt", "w")
textFile.write("Clean House, Low\n")
textFile.write("Pay Bills, High\n")
textFile.close()

# open text file
textFile = open("ToDo.txt", "r")

# variables
dictionaryRow = {}  # dictionary of initial data
todoList = []  # full to do list

# add item to dictionary
textFile = open("ToDo.txt", "r")
for line in textFile:
    (key, value) = line.split(', ')
    dictionaryRow[key] = value.strip('\n')

# add item to list
for key, value in dictionaryRow.items():
    newRow = {key: value}
    todoList.append(newRow)

# condition on whether to keep loop going
condition = ""

# display menu items for choices
while condition != 'done':
    print('''
    Program Menu:
    0 - Exit Program 
    1 - View To Do List
    2 - Add New Task
    3 - Remove a Task
    4 - Save Data
    ''')

    choice = input("Select an Option: ")

# if choice 0 exit program
    if choice == '0':
        while True:
            exitProgram = input("Would you like to exit the program? [y/n]: ")
            if exitProgram.lower() == 'n':
                break
            elif exitProgram.lower() == 'y':
                print("Goodbye!")
                condition = 'done'
                break
            else:
                print("That is not a valid response.")

# if choice 1 show data
    elif choice == '1':
        print("Priority : Task")
        for item in todoList:
            print(item)

# if choice 2 add new item
    elif choice == '2':
        while True:
            newTask = input("What is the new task to add? Enter 'exit' to return to the menu: ")
            if newTask.lower() == 'exit':
                break
            else:
                newPriority = input("What is the priority for this new task?: ")
                if newPriority.lower() == 'low' or 'high':
                    newList = {newTask: newPriority}
                    todoList.append(newList)
                elif newPriority.lower() != 'low' or 'high':
                    print("You can only have 'low' or 'high' as a priority.")


# if choice 3 remove item
    elif choice == '3':
        counter = 0
        for item in todoList:
            print(counter)
            counter += 1
            print(item)
        removeTask = int(input("Which task would you like to remove? Enter the number above the task: "))
        todoList.remove(todoList[removeTask])
        print("Your new to do list is:")
        print(todoList)
# if choice 4 save data
    elif choice == '4':

        saveData = input("Would you like to save the to do list to 'ToDo.txt'? [y/n]: ")
        if saveData.lower() == 'n':
            print("Your data was not saved.")
        elif saveData.lower() == 'y':
            textFile = open("ToDo.txt", "w")
            for item in todoList:
                textFile.write(str(item) + "\n")
            input("Your data has been saved. Press the enter key to return to the menu.")
            textFile.close()
        else:
            print("That is not a valid response.")

#if incorrect choice
    else:
        print("That is not a valid response.")


