# ---------------------------------------------- #
# Title: HomeInventory
# Dev: Andrew Garcia
# Date: 11/10/2018
# Changelog: Andrew Garcia, 11/10/2018, Created
# Andrew Garcia, 11/25/18, Updated for Assignment06
# ---------------------------------------------- #

# script that allows users to look at their to do list and be able to edit the list as they choose

dictionaryRow = {}  # dictionary of initial data
todoList = []  # full to do list
action = ""  # the menu option the user decides on
newTask = ""  # adding a new task to list
newPriority = ""  # adding a new priority
removeTask = ""  # removing a task


# creating a class to edit the to do list
class toDoMethod():
    # create text file with some data
    def startProgram():
        textFile = open("ToDo.txt", "w")
        textFile.write("Clean House, Low\n")
        textFile.write("Pay Bills, High\n")
        textFile.close()

    # adding items to a dictionary
    def toDictionary():
        textFile = open("ToDo.txt", "r")
        textFile = open("ToDo.txt", "r")
        for line in textFile:
            (key, value) = line.split(', ')
            dictionaryRow[key] = value.strip('\n')

    # adding items to list
    def toList():
        for key, value in dictionaryRow.items():
            newRow = {key: value}
            todoList.append(newRow)

    # showing menu of options to user
    def printMenu():
        options = ('''
            Program Menu:
            0 - View To Do List
            1 - Add New Task
            2 - Remove a Task
            3 - Save Data
            4 - Exit Program
            ''')
        return options

    # prints to do list to user
    def printToDoList():
        print("Priority : Task")
        for item in todoList:
            print(item)

    # adds new item to list
    def addList(newTask, newPriority):
        addingTask = {newTask: newPriority}
        todoList.append(addingTask)
        taskAdded = "Your new task has been added."
        return taskAdded

    # creates a counter to show user options
    def counter():
        counter = 0
        for item in todoList:
            print(counter)
            counter += 1
            print(item)

    # removing item from list
    def removeList(removeTask):
        try:
            todoList.remove(todoList[removeTask])
            removed = "Your task has been removed."
            return removed
        except:
            wrongInput = "That is not a valid input."
            return wrongInput

    # saving items to text file
    def saveList():
        textFile = open("ToDo.txt", "w")
        for item in todoList:
            textFile.write(str(item) + "\n")
        isSaved = "Your data has been saved."
        textFile.close()
        return isSaved

# start of script
print("Welcome to your To Do List!")
print("Here you can perform different tasks related to your to do list.")

# creating
toDoMethod.startProgram()
toDoMethod.toDictionary()
toDoMethod.toList()

# loop that allows users to do play around with to do list
while True:
    print(toDoMethod.printMenu())
    action = input("Which option would you like?:  ")
    if action == '0':
        toDoMethod.printToDoList()
    elif action == '1':
        newTask = input("What is the task?: ")
        newPriority = input("What is the priority? [High/Low]: ")
        print(toDoMethod.addList(newTask, newPriority))
    elif action == '2':
        toDoMethod.counter()
        removeTask = int(input("Which task would you like to remove? Enter the number above the task: "))
        print(toDoMethod.removeList(removeTask))
    elif action == '3':
        print(toDoMethod.saveList())
    elif action == "4":
        break
    else:
        print("That is not a valid option.")
